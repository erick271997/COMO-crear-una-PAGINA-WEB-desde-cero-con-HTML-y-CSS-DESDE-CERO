# Pagina-web-efecto-skew

### Un asombroso sitio web creado con un efecto skew, que la hará ver muy innovadora.

### [Da Click Aquí para apoyarme en YouTube](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)

### [Tutorial: https://youtu.be/q6Is8k9x7Eg](https://youtu.be/q6Is8k9x7Eg)

![AlexCG Design](https://github.com/AlexCGDesign/Pagina-web-efecto-skew/blob/master/Pagina%20web%20-%20Skew/Mockup.png)

### Hecho por: [AlexCG Design](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)
